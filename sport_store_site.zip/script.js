let cart = [];
let total = 0;

function addToCart(name, price) {
  cart.push({name, price});
  total += price;
  document.getElementById('cart-count').innerText = cart.length;
}

document.getElementById('cart-btn').addEventListener('click', () => {
  const cartDiv = document.getElementById('cart');
  const cartItems = document.getElementById('cart-items');
  cartItems.innerHTML = '';
  cart.forEach(item => {
    const li = document.createElement('li');
    li.innerText = item.name + ' - R$ ' + item.price.toFixed(2);
    cartItems.appendChild(li);
  });
  document.getElementById('cart-total').innerText = total.toFixed(2);
  cartDiv.style.display = 'block';
});

function closeCart() {
  document.getElementById('cart').style.display = 'none';
}

function checkout() {
  let message = 'Olá! Gostaria de comprar:%0A';
  cart.forEach(item => {
    message += '- ' + item.name + ' (R$ ' + item.price.toFixed(2) + ')%0A';
  });
  message += 'Total: R$ ' + total.toFixed(2);
  window.open('https://wa.me/5599999999999?text=' + message, '_blank');
}
